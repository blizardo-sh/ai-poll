# Файлы кейса

Все данные синтетические.

- input/audit-task.md — задача руководителя аудиторской проверки
- input/requests.csv — 10 заявок, фактические даты 2–15 сентября 2026
- input/regulation-4.2.md — регламент, пункты 4.1–4.5
- evidence/control-register.md — реестр контроля
- evidence/change-log.md — изменения суммы
- evidence/approval-log.md — технические события

Исходники только читаются. Ответы агента — в drafts. Принятые человеком файлы — в output.
